// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBnClL5nBjC8mEZLIInsR2SEGzDBXKuMU0",
  authDomain: "microbit-temp-60bda.firebaseapp.com",
  databaseURL: "https://microbit-temp-60bda-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "microbit-temp-60bda",
  storageBucket: "microbit-temp-60bda.appspot.com",
  messagingSenderId: "858639097565",
  appId: "1:858639097565:web:0503bb099301633ba90534",
  measurementId: "G-0DLMJNF0YP"
};


// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Retrieve the database handle (handle is a type of function)
const myDB = firebase.database().ref('/Information');

const btn = document.getElementById("submitData");
btn.addEventListener("click",saveData);

// Submit clicked so post the data to the server
function saveData() {
  // Read the data from the first name field
  const fNameField = document.getElementById("firstName");
  const fNameFieldValue = fNameField.value;
 
  // Read the data from the last name field
  const lNameField = document.getElementById("lastName");
  const lNameFieldValue = lNameField.value;
 
   // Read the data from the age field
  const ageField = document.getElementById("age");
  const ageFieldValue = ageField.value;

  // code to save the data to Firebase GOES HERE!
  const data = myDB.push();
  data.set( {firstName: fNameFieldValue,lastName: lNameFieldValue,age: ageFieldValue});
}